const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const nodemailer = require('nodemailer');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '2mb' }));
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/sendEmails', async (req, res) => {
    const { emails, subject, body, smtpDetails, minInterval, maxInterval } = req.body;

    console.log(typeof emails, emails);

    let emailsList;
    
    if (Array.isArray(emails) && emails.length === 1 && typeof emails[0] === 'string') {
      // Split the single string in the array into multiple emails
      emailsList = emails[0].split("\n");
    } else {
      // Handle other cases or throw an error
      throw new TypeError("Expected emails to be an array with a single string element");
    }
    
    console.log(emailsList);
        // Check if smtpDetails is provided and is an array of objects
    if (!smtpDetails || !Array.isArray(smtpDetails)) {
        return res.status(400).json({ message: "Invalid or missing SMTP details." });
    }

    // Ensure each SMTP detail is valid
    const smtpServers = smtpDetails.filter(detail => {
        return detail.smtpServer && detail.email && detail.password;
    });

    if (smtpServers.length === 0) {
        return res.status(400).json({ message: "Invalid SMTP configurations provided." });
    }

    // Function to create a transporter
    const createTransporter = (smtp) => {
        return nodemailer.createTransport({
            host: smtp.smtpServer,
            port: 587,
            secure: false,  // true for 465, false for other ports
            auth: {
                user: smtp.email,
                pass: smtp.password
            }
        });
    };

    // Function to send an email
    const sendEmail = async (email, subject, body, smtp) => {
        const transporter = createTransporter(smtp);
        return transporter.sendMail({
            from: `"From Email" <${smtp.email}>`,  // sender address
            to: email,  // receiver
            subject: subject,
            text: body,
            html: body
        });
    };

    // Loop over emails and send them with randomized delay
    emailsList.forEach((email, index) => {
        const delay = minInterval + Math.random() * (maxInterval - minInterval) * 1000;
        setTimeout(() => {
            const smtp = smtpServers[Math.floor(Math.random() * smtpServers.length)];
            sendEmail(email, subject, body, smtp)
                .then(result => console.log(`Email sent to ${email}`))
                .catch(error => console.error(`Failed to send email to ${email}: `, error));
        }, delay * index);
    });

    res.json({ message: "Emails are being sent." });
});

const PORT = 4000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
